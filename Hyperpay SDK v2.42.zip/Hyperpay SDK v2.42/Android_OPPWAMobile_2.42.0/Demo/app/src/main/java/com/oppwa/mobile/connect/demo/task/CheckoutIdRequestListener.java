package com.oppwa.mobile.connect.demo.task;


public interface CheckoutIdRequestListener {

    void onCheckoutIdReceived(String checkoutId);
}
