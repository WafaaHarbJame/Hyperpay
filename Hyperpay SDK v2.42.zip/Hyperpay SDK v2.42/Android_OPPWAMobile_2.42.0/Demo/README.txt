Before running the application, make sure the libraries files are copied to the following folders:

oppwa.mobile:
Remove the version number and copy 'oppwa.mobile.aar' to the 'oppwa.mobile' folder.

alipay:
Copy 'alipaySdk-15.5.9.aar' to the 'alipay' folder.